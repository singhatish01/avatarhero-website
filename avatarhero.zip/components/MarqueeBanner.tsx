
import React from 'react';

const MarqueeItem: React.FC<{ text: string, icon: string, isStroked?: boolean }> = ({ text, icon, isStroked }) => (
  <span className={`text-3xl font-bold uppercase tracking-wider flex items-center gap-4 ${isStroked ? 'text-white text-stroke' : 'text-black'}`}>
    {text} <span className="material-icons text-4xl">{icon}</span>
  </span>
);

const MarqueeBanner: React.FC = () => {
  const items = [
    { text: 'SCALE', icon: 'bolt' },
    { text: 'AUTOMATE', icon: 'smart_toy', isStroked: true },
    { text: 'CREATE', icon: 'auto_fix_high' },
    { text: 'SLEEP', icon: 'bedtime', isStroked: true },
    { text: 'REPEAT', icon: 'loop' },
  ];

  return (
    <div className="py-6 bg-primary transform -rotate-1 border-y-4 border-black relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
      <div className="flex space-x-12 animate-marquee whitespace-nowrap">
        {items.map((item, index) => <MarqueeItem key={index} {...item} />)}
        {items.map((item, index) => <MarqueeItem key={`dup-${index}`} {...item} />)}
      </div>
    </div>
  );
};

export default MarqueeBanner;
