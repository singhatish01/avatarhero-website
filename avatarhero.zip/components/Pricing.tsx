
import React from 'react';

interface FeatureItemProps {
    children: React.ReactNode;
}

const FeatureItem: React.FC<FeatureItemProps> = ({ children }) => (
    <li className="flex items-center gap-3">
        <span className="material-icons text-secondary text-base">check</span> {children}
    </li>
);

const Pricing: React.FC = () => {
  return (
    <section className="py-24 bg-black/30" id="pricing">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Invest in your <span className="text-primary">Time</span></h2>
          <p className="text-gray-400">Choose the plan that fits your scaling needs.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 items-center">
          {/* Starter Plan */}
          <div className="bg-background-dark border border-white/10 rounded-2xl p-8 hover:border-gray-500 transition-colors">
            <h3 className="text-xl font-bold text-gray-300 mb-2">Starter</h3>
            <div className="flex items-baseline mb-6">
              <span className="text-4xl font-bold text-white">$49</span>
              <span className="text-gray-500 ml-2">/month</span>
            </div>
            <ul className="space-y-4 mb-8 text-gray-400 text-sm">
              <FeatureItem>1 AI Avatar</FeatureItem>
              <FeatureItem>30 mins video / mo</FeatureItem>
              <FeatureItem>1080p Export</FeatureItem>
              <FeatureItem>Standard Voices</FeatureItem>
            </ul>
            <button className="w-full py-3 px-4 rounded-lg bg-white/10 text-white hover:bg-white/20 font-bold transition-colors">Get Started</button>
          </div>
          {/* Founder Plan */}
          <div className="relative bg-background-dark border-2 border-primary rounded-2xl p-8 transform md:-translate-y-4 shadow-[0_0_30px_rgba(173,43,238,0.15)]">
            <div className="absolute top-0 right-0 bg-primary text-white text-xs font-bold px-3 py-1 rounded-bl-xl rounded-tr-lg">MOST POPULAR</div>
            <h3 className="text-xl font-bold text-white mb-2">Founder</h3>
            <div className="flex items-baseline mb-6">
              <span className="text-4xl font-bold text-white">$99</span>
              <span className="text-gray-500 ml-2">/month</span>
            </div>
            <ul className="space-y-4 mb-8 text-gray-300 text-sm">
              <FeatureItem>3 AI Avatars</FeatureItem>
              <FeatureItem>120 mins video / mo</FeatureItem>
              <FeatureItem>4K Export</FeatureItem>
              <FeatureItem>Voice Cloning</FeatureItem>
              <FeatureItem>API Access</FeatureItem>
            </ul>
            <button className="w-full py-3 px-4 rounded-lg bg-primary text-white hover:bg-primary/90 font-bold transition-colors shadow-lg shadow-primary/30">Get Founder Plan</button>
          </div>
          {/* Agency Plan */}
          <div className="bg-background-dark border border-white/10 rounded-2xl p-8 hover:border-gray-500 transition-colors">
            <h3 className="text-xl font-bold text-gray-300 mb-2">Agency</h3>
            <div className="flex items-baseline mb-6">
              <span className="text-4xl font-bold text-white">$299</span>
              <span className="text-gray-500 ml-2">/month</span>
            </div>
            <ul className="space-y-4 mb-8 text-gray-400 text-sm">
              <FeatureItem>Unlimited Avatars</FeatureItem>
              <FeatureItem>Unlimited video</FeatureItem>
              <FeatureItem>Priority Processing</FeatureItem>
              <FeatureItem>Whitelabeling</FeatureItem>
            </ul>
            <button className="w-full py-3 px-4 rounded-lg bg-white/10 text-white hover:bg-white/20 font-bold transition-colors">Contact Sales</button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
