
import React from 'react';

const Header: React.FC = () => {
  return (
    <nav className="fixed w-full z-50 top-0 start-0 border-b border-white/10 bg-background-dark/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-center justify-between py-4">
          <a className="flex items-center gap-2 group" href="#">
            <div className="relative w-10 h-10 bg-primary rounded-lg flex items-center justify-center transform group-hover:rotate-12 transition-transform">
              <span className="material-icons text-white">face</span>
              <div className="absolute -inset-1 bg-secondary rounded-lg blur opacity-40 group-hover:opacity-75 transition duration-200"></div>
            </div>
            <span className="self-center text-2xl font-bold whitespace-nowrap tracking-tight">Avatar<span className="text-primary">Hero</span></span>
          </a>
          <div className="hidden md:flex items-center space-x-8">
            <a className="text-gray-300 hover:text-secondary transition-colors font-medium" href="#process">How it Works</a>
            <a className="text-gray-300 hover:text-accent transition-colors font-medium" href="#founders">Founders Wall</a>
            <a className="text-gray-300 hover:text-primary transition-colors font-medium" href="#pricing">Pricing</a>
          </div>
          <div className="flex items-center gap-4">
            <a className="hidden sm:block text-sm font-medium hover:text-primary transition-colors" href="#">Login</a>
            <button className="text-black bg-secondary hover:bg-secondary/90 focus:ring-4 focus:outline-none focus:ring-lime-300 font-bold rounded-lg text-sm px-5 py-2.5 text-center transform hover:scale-105 transition-all shadow-[0_0_15px_rgba(163,230,53,0.4)]" type="button">
              Start Creating
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Header;
