
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Abstract Background Blobs */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob"></div>
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-accent/20 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-32 left-1/3 w-96 h-96 bg-secondary/20 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-primary/30 bg-primary/10 backdrop-blur-sm">
              <span className="flex h-2 w-2 rounded-full bg-secondary animate-pulse"></span>
              <span className="text-sm font-medium text-primary tracking-wide uppercase">AI Video Generation v2.0 is Live</span>
            </div>
            <h1 className="text-5xl lg:text-7xl font-bold leading-tight tracking-tight">
              Scale Yourself: <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-secondary">Your AI Twin</span> <br />
              Never Sleeps.
            </h1>
            <p className="text-lg text-gray-400 max-w-lg leading-relaxed">
              Clone your face, voice, and mannerisms. Create unlimited content 24/7 while you nap, travel, or build your empire. The future is automated.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <button className="relative inline-flex group items-center justify-center px-8 py-4 font-bold text-white transition-all duration-200 bg-primary rounded-lg hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary animate-pulse-glow">
                <span className="absolute inset-0 w-full h-full -mt-1 rounded-lg opacity-30 bg-gradient-to-b from-transparent via-transparent to-black"></span>
                <span className="relative flex items-center gap-2">
                  Get Your Avatar
                  <span className="material-icons text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
                </span>
              </button>
              <button className="inline-flex items-center justify-center px-8 py-4 font-bold text-white transition-all duration-200 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 focus:outline-none backdrop-blur-sm">
                <span className="material-icons mr-2 text-secondary">play_circle</span>
                Watch Demo
              </button>
            </div>
            <div className="flex items-center gap-4 pt-8 text-sm text-gray-500">
              <div className="flex -space-x-3">
                <img alt="User avatar 1" className="w-10 h-10 border-2 border-background-dark rounded-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuD1MW8-vNhkPVu97To6Oy1lRvfEDNE8sSEESwLEy7wPLnod7mBULb3NNe4DR_Sd9dzHZtD-RfdrdESxGb65TL_6HW-IeKBanRsnT9AAmQVmCEFUcXZOS6ZeaGIZDnyQ-g0Z8gXKqwpHKWdiuxjkXnLS_iWFTYPaCHM4HxQyembnhiTZ5d9cXMHxZR8AnWqLnMlZPEb746K1iCqRuDVHTZ-vgnCRrQpD3_NL-6aSpSI6lS_Ix_yZFe4Hov6tnNToAoN_tTw2j389iwwT" />
                <img alt="User avatar 2" className="w-10 h-10 border-2 border-background-dark rounded-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCe_-uH6_muI5bfqRUvRXWuR_b1qv8c3RWkQw4r8z9VeT8xHRu-0JNvfTL6Rq_iJe277rYl5F5AqNzkDN_eTSrne37h4a3GWE3kSUyBgHPWN6Wpy4-KA9hwIvqzYzsum8_jauje48LL5oC4brlVrRsPF2iMuE7wcioSqnjLUClv2vEntxg_3EcieA9ZLZAQROEdoNtjhyO3O_vcvkCxBJorvSVkvelMK9nBIcznivHOa_neG0KPTVv78iyhJnKzyoXoIdr8qDz_KNE5" />
                <img alt="User avatar 3" className="w-10 h-10 border-2 border-background-dark rounded-full" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAAemMitBGUXQ_vop14rqgHhTsVmSKx1JGJ4pA7LzOHsta0l0_0TvU8vLRqzAr3w1cq4NVzspsJVpWsoknA-2dLpC4OTIEU5HZVpHu7oT84NoDrRYpQnjFayOlgFWFBFsaGYn_SbioVm1M0aiLWlDSlHhORbnlf6EYpb9Q_dx6zg3e3TwHYeFjhHf-BRL1QIsnp7U2ngVYgOZzSLml9lilNOR0Uyxvr61RgY3aNgoo97loMHVdBBVCsSSQOlzhSu5rWOmflQG2dB27m" />
                <div className="flex items-center justify-center w-10 h-10 text-xs font-medium text-white bg-gray-700 border-2 border-background-dark rounded-full hover:bg-gray-600">
                  +2k
                </div>
              </div>
              <p>Joined by 2,000+ Founders</p>
            </div>
          </div>
          <div className="relative hidden lg:block animate-float">
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-secondary rounded-full mix-blend-multiply filter blur-xl opacity-50"></div>
            <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-accent rounded-full mix-blend-multiply filter blur-xl opacity-50"></div>
            <div className="relative bg-gradient-to-b from-gray-800 to-black rounded-[2rem] p-4 border border-white/10 shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-500">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -mt-3 w-20 h-6 bg-black rounded-b-xl z-20 flex justify-center items-center gap-2">
                <div className="w-1 h-1 bg-gray-600 rounded-full"></div>
                <div className="w-8 h-1 bg-gray-600 rounded-full"></div>
              </div>
              <img alt="3D animated style founder avatar with glowing purple glasses" className="w-full rounded-2xl aspect-[4/5] object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuArk1CFmcHRwcELXDQ-0JVAsakGgHc6wyuj1ZpixE4IAbmxPP6a_4oz_EidBhmz-8PIvNYANMpILO7BB5bH4TsNLdxhrHSDAYO3ENAWBTuGfz7EBh_laI2hQMNE85YcMfkTvp_RmEOSiBRLIeLZ6jhp_ioFrFddRFc9x9kY-3lDMd36HfJdR5Q13dbTfX0X_cpnHLwMoe8empMN1CBF4V4SagQFtV5FDUYWQhzSLDFCADgm3OBYtNkz35vhl9bLI7tb9VYxql6kTwC9" />
              <div className="absolute bottom-8 left-8 right-8 bg-black/60 backdrop-blur-md rounded-xl p-4 border border-white/10">
                <div className="flex items-center gap-3 mb-2">
                  <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                  <span className="text-xs font-mono text-secondary uppercase">Recording...</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-1.5 mb-2">
                  <div className="bg-gradient-to-r from-primary to-accent h-1.5 rounded-full" style={{ width: '45%' }}></div>
                </div>
                <div className="flex justify-between text-xs text-gray-400 font-mono">
                  <span>Generating Voice</span>
                  <span>45%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
