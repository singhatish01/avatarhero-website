
import React from 'react';

interface StepCardProps {
    step: string;
    title: string;
    description: string;
    icon: string;
    shadowColor: string;
    stepColor: string;
    animateIcon?: boolean;
}

const StepCard: React.FC<StepCardProps> = ({ step, title, description, icon, shadowColor, stepColor, animateIcon }) => (
    <div className="group relative bg-white/5 border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-all duration-300 hover:-translate-y-2">
        <div className={`absolute -top-6 left-8 bg-background-dark border border-white/10 rounded-lg px-4 py-2 text-2xl font-bold ${stepColor} ${shadowColor}`}>
            {step}
        </div>
        <div className={`h-48 w-full bg-gradient-to-br from-gray-800 to-black rounded-xl mb-6 flex items-center justify-center overflow-hidden relative group-hover:shadow-[0_0_20px] transition-shadow ${shadowColor}`}>
            <div className={`absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] ${shadowColor.replace('shadow-', 'from-')}/20 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity`}></div>
            <span className={`material-icons text-6xl text-white z-10 ${animateIcon ? 'animate-spin' : ''}`}>{icon}</span>
        </div>
        <h3 className="text-2xl font-bold mb-3">{title}</h3>
        <p className="text-gray-400">{description}</p>
    </div>
);


const HowItWorks: React.FC = () => {
  return (
    <section className="py-24 bg-background-dark relative" id="process">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">How It <span className="text-secondary underline decoration-wavy decoration-primary underline-offset-8">Works</span></h2>
          <p className="text-gray-400 text-lg">Three steps to immortality (digitally speaking).</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
            <StepCard 
                step="01"
                title="Record Yourself"
                description="Upload a 2-minute video of yourself speaking naturally. No fancy studio required, just good lighting and your beautiful face."
                icon="videocam"
                stepColor="text-secondary"
                shadowColor="shadow-secondary"
            />
            <StepCard 
                step="02"
                title="AI Training"
                description="Our neural engine analyzes your micro-expressions and voice patterns to build a hyper-realistic digital twin in < 24 hours."
                icon="settings_suggest"
                stepColor="text-accent"
                shadowColor="shadow-accent"
                animateIcon
            />
            <StepCard 
                step="03"
                title="Create Magic"
                description="Type any text, and watch your avatar deliver it perfectly. Scale your content production to infinity."
                icon="movie_creation"
                stepColor="text-primary"
                shadowColor="shadow-primary"
            />
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
