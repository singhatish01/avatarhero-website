
import React from 'react';

interface FounderCardProps {
    name: string;
    title: string;
    imageUrl: string;
    className?: string;
}

const FounderCard: React.FC<FounderCardProps> = ({ name, title, imageUrl, className = '' }) => (
    <div className={`relative group rounded-xl overflow-hidden aspect-[9/16] cursor-pointer ${className}`}>
        <img alt={`Video thumbnail of ${name}`} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" src={imageUrl} />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80"></div>
        <div className="absolute bottom-0 left-0 p-4 w-full">
            <div className="flex items-center gap-2 mb-2">
                <span className="bg-secondary text-black text-xs font-bold px-2 py-0.5 rounded">AI GENERATED</span>
            </div>
            <h4 className="font-bold text-white text-lg">{name}</h4>
            <p className="text-gray-300 text-xs">{title}</p>
        </div>
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="w-16 h-16 bg-primary/80 rounded-full flex items-center justify-center backdrop-blur-sm">
                <span className="material-icons text-white text-3xl">play_arrow</span>
            </div>
        </div>
    </div>
);

const FoundersWall: React.FC = () => {
    const founders = [
        { name: "Sarah Jenkins", title: "CEO, TechFlow", imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAxlZJZm-ELbXyc_M-UDKEaY-MtLuoBZNIH9UlQdeA7Dlspuoc2CiX5j7LGXKCKuD5E61QSJ9hfZLrC3_FdpjG5Am3qoFNkG0vasmtSuNIXSL8O2X_2xk32JzE89vRFrNaTgcX5KxEy_iH7kEG1JkQAAkF16VMmDkWNueZpW2orEHmId06sIIbLFWVY8LuwiOiFvaEJ7mp_s1J7ZxRGfamH4xXK7qEL6nEjtq2EAGFqSmwyiOKx_AmnEB8BZtaFQK3aEv3hNo5SIcZ9", className: "" },
        { name: "David Chen", title: "Founder, StartUpX", imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuCDUcjahDMhUXqJlG_zaekN5u7sbIFTtSr96zqZTqQYZbR_GOUqafvOUbSqW56WgeQNANeW_haGbcVf_e79opme5rKN3CKOEqBkwji8mY1McetUuePk8FG2pJ-eicWzUfagw0KByrDpPpq7IhqdPo9l-ExB7t6X2Z6X2DClJGXEY-K1nmsF235JIYOp78BDc2vYVfzIr2Cm-JWm_h3SdcirDGQAXQ7L7Y_VPkCsE041bUX9dx1Sa9gXsImo-dJbPz4cw28tWw2eyo4t", className: "lg:mt-12" },
        { name: "Elena Rodriguez", title: "Creator, ArtDigital", imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuA-jwnun-p0bbDqBoRw8n_jhbmPBWK4fzr-ZfxYjJZZ5b-xD3Kb-N2T_qftGD9KiFIsUXGmVAGN00zWzjsOcr8w-ovzC30VcK3pafkWImP9AiSFf_SX-JxKgErzAjZ8evkHWQLi_rWnADXjsqnY7_7pgMsgcJD98f98wHtJPbD6zXs2A_KuFsxqFsYjhBucYr_PnZrKCeKHAt49iOoSP-U6dNQSP-4Llai4WJeDRPrSF5hcysCoMYzmFug5RvOO3a5u0nicYIR3Fvki", className: "" },
        { name: "Marcus Johnson", title: "Coach, PeakPerformance", imageUrl: "https://lh3.googleusercontent.com/aida-public/AB6AXuAD5HEI7JTcKu8zPvVpzME_J-GD0AXAic0reNS1Z3_ufq_f2BwC38vVoVROv8UPOG1ir6tHv1Z-6f-o013qIvEmCF-L3gmaO19Gy7OeVW4eGRhsNsVAg_HGjw68iaxovbBxqEW3EKlM9GmsQpnJVqQJIgTnINuBGtrVAAgHneeVSoKJlzWc5MbxmbFkhaTddU6v2AMxPBoG7_tAmeb1ls34PcZNxWEHASNgkD2i8yUqr-5NOTkj4bHJRgg8rU50q8L9f5H4uvbPdvn1", className: "lg:mt-12" },
    ];

    return (
        <section className="py-24 relative overflow-hidden" id="founders">
            <div className="absolute top-1/2 left-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl -translate-y-1/2"></div>
            <div className="absolute bottom-0 right-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl translate-y-1/2"></div>
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
                    <div>
                        <h2 className="text-4xl md:text-5xl font-bold mb-2">The Founders <span className="text-accent">Wall</span></h2>
                        <p className="text-gray-400">See who's already scaling with their digital twin.</p>
                    </div>
                    <button className="text-white hover:text-secondary font-medium flex items-center gap-2 group">
                        View all testimonials <span className="material-icons group-hover:translate-x-1 transition-transform">arrow_right_alt</span>
                    </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {founders.map((founder, index) => (
                        <FounderCard key={index} {...founder} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default FoundersWall;
