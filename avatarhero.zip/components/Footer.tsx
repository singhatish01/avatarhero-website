
import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="border-t border-white/10 bg-background-dark pt-16 pb-8">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid md:grid-cols-4 gap-12 mb-12">
                    <div className="col-span-1 md:col-span-2">
                        <a className="flex items-center gap-2 mb-4" href="#">
                            <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
                                <span className="material-icons text-white text-sm">face</span>
                            </div>
                            <span className="text-xl font-bold">Avatar<span className="text-primary">Hero</span></span>
                        </a>
                        <p className="text-gray-400 max-w-sm mb-6">The world's leading AI avatar platform for founders who want to scale their personal brand without burning out.</p>
                        <div className="flex space-x-4">
                            <a className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary/20 hover:text-primary transition-colors text-white" href="#">
                                <span className="text-sm font-bold">𝕏</span>
                            </a>
                            <a className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary/20 hover:text-primary transition-colors text-white" href="#">
                                <span className="text-sm font-bold">In</span>
                            </a>
                            <a className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-primary/20 hover:text-primary transition-colors text-white" href="#">
                                <span className="text-sm font-bold">Ig</span>
                            </a>
                        </div>
                    </div>
                    <div>
                        <h4 className="font-bold text-white mb-4 uppercase text-sm tracking-wider">Product</h4>
                        <ul className="space-y-2 text-gray-400 text-sm">
                            <li><a className="hover:text-primary transition-colors" href="#">Features</a></li>
                            <li><a className="hover:text-primary transition-colors" href="#">Pricing</a></li>
                            <li><a className="hover:text-primary transition-colors" href="#">Showcase</a></li>
                            <li><a className="hover:text-primary transition-colors" href="#">Integrations</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-bold text-white mb-4 uppercase text-sm tracking-wider">Company</h4>
                        <ul className="space-y-2 text-gray-400 text-sm">
                            <li><a className="hover:text-primary transition-colors" href="#">About</a></li>
                            <li><a className="hover:text-primary transition-colors" href="#">Blog</a></li>
                            <li><a className="hover:text-primary transition-colors" href="#">Careers</a> <span className="text-xs bg-secondary text-black px-1.5 rounded ml-1">Hiring</span></li>
                            <li><a className="hover:text-primary transition-colors" href="#">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div className="border-t border-white/10 pt-8 mt-8">
                    <div className="flex flex-col md:flex-row justify-between items-center gap-6">
                        <div className="text-sm text-gray-500">
                            © 2023 AvatarHero Inc. All rights reserved.
                        </div>
                        <div className="flex items-center gap-2">
                            <input className="bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-primary w-64" placeholder="Enter your email for updates" type="email" />
                            <button className="bg-primary hover:bg-primary/90 text-white rounded-lg px-4 py-2 text-sm font-bold transition-colors">Subscribe</button>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
