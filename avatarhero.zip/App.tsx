
import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import MarqueeBanner from './components/MarqueeBanner';
import HowItWorks from './components/HowItWorks';
import FoundersWall from './components/FoundersWall';
import Pricing from './components/Pricing';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <MarqueeBanner />
        <HowItWorks />
        <FoundersWall />
        <Pricing />
      </main>
      <Footer />
    </>
  );
};

export default App;
